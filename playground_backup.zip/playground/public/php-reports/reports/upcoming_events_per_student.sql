-- Upcoming events for each student
-- This report lets you view all events scheduled within the specified time frame for current students.
-- FILTER: {
--   filter: "twig",
--   column: "Event ID",
--   params: {
--     template: "<a href='http://pgrs.dev.lord.technology/students/{{ row.Enrolment_ID }}/events/{{ value }}' target='_blank'>{{ value }}</a>",
--     html: true
--   }
-- }
-- FILTER: {
--   filter: "twig",
--   column: "Enrolment_ID",
--   params: {
--     template: "<a href='http://pgrs.dev.lord.technology/students/{{ value }}' target='_blank'>{{ value }}</a>",
--     html: true
--   }
-- }
-- VARIABLE: {
--   name: "gs_form",
--   display: "GS Form",
--   type: "select",
--   options: ["GS1","GS2","GS3","GS4","GS5","GS5B","GS6","GS6a","GS6b","GS6c","GS6d","GS6e","GS6f","GS6g","GS7","GS8","GS9","GS10","GS10a","GS11","GS12","GS13"]
-- }
-- VARIABLE: {
--     "name": "startBefore",
--     "display": "Expected start before",
--     "type": "date"
-- }

SELECT
events.id as "Event ID",
CONCAT_WS(' ', users.title, users.first_name, users.last_name) as "Full name",
students.enrolment as "Enrolment_ID",
gs_forms.name as "GS Form",
events.start as "Expected start"
FROM
students
INNER JOIN
events on events.student_id = students.id
INNER JOIN
users on users.id = students.user_id
INNER JOIN
gs_forms on events.gs_form_id = gs_forms.id
WHERE
students.end > DATE(NOW())
AND
events.submitted_at IS NULL
AND
events.approved_at IS NULL
AND
gs_forms.name = "{{gs_form}}"
AND
events.start > DATE(NOW())
AND
events.start < "{{startBefore}}"
ORDER BY
"Expected start"