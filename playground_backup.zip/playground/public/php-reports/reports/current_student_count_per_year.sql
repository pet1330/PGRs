-- Current students per year
-- This report lets you view all students by their current year of study.
-- FILTER: {
--   filter: "twig",
--   column: "Enrolment ID",
--   params: {
--     template: "<a href='http://pgrs.dev.lord.technology/students/{{ value }}' target='_blank'>{{ value }}</a>",
--     html: true
--   }
-- }

SELECT
CONCAT_WS(' ', users.title, users.first_name, users.last_name) as "Full name",
students.enrolment as "Enrolment ID",
students.start as "Start date",
students.end as "End date",
floor(datediff(curdate(),students.start)/365)+1 as "Year"
FROM
users,
students
WHERE
users.id = students.user_id
AND
students.start <= DATE(NOW())
AND
students.end > DATE(NOW())
ORDER BY
Year