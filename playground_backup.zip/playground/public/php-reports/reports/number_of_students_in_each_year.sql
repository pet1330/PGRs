-- Number of students in each year
-- This report lets you view all current students by their current year of study.
-- CHART: {
-- 	"columns": ["Year", "Number of students"],
-- 	"type": "ColumnChart",
-- 	"title": "Number of students in each year of study",
-- 	"width": "400px",
-- 	"height": "400px"
-- }

SELECT
floor(datediff(curdate(),students.start)/365)+1 as Year,
COUNT(*) as "Number of students"
FROM
users,
students
WHERE
users.id = students.user_id
AND
students.start <= DATE(NOW())
AND
students.end > DATE(NOW())
GROUP BY Year
ORDER BY Year