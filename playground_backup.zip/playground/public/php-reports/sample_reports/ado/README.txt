Reports written in SQL. 
AdoDB library is responsible for making and maintaining the DB connectivity. Some additional extensions for PHP can be neccessary in order to work with certain databases.
