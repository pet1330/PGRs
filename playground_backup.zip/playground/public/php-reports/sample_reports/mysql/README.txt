Reports written in SQL.  The mysql or mysqli PHP extension is required for these reports.
