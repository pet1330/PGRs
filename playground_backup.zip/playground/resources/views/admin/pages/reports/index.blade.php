@extends('admin.layouts.reports_master')
@section('content')

<div class="embed-responsive embed-responsive-4by3">
    <iframe src="/php-reports" class="embed-responsive-item"></iframe>
</div>

@endsection
@stop