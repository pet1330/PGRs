@extends(Auth::user()->default_layout)
@section('title', 'This page is blank')
@section('content')
    This is a blank page.
@endsection
@stop